from pathlib import Path
import duckdb

SQL_DIR = Path("sql")
DB_DIR = Path("duckdb")
DB_DIR.mkdir(exist_ok=True)

for sql_file in sorted(SQL_DIR.glob("*_duckdb_seeded_corrected.sql")):
    db_id = sql_file.name.replace("_duckdb_seeded_corrected.sql", "")
    db_path = DB_DIR / f"{db_id}.duckdb"

    if db_path.exists():
        db_path.unlink()

    print(f"Building {db_path} from {sql_file}")
    conn = duckdb.connect(str(db_path))
    conn.execute(sql_file.read_text(encoding="utf-8"))
    conn.close()

print("Done.")
