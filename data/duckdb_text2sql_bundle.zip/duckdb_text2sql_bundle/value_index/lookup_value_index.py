import json
import re
from pathlib import Path
from rapidfuzz import fuzz

VALUE_INDEX_PATH = Path("value_index/value_index.jsonl")

def normalize(text: str) -> str:
    text = str(text).strip().lower()
    text = re.sub(r"\s+", " ", text)
    return text

def load_value_index(path=VALUE_INDEX_PATH, db_id=None):
    rows = []
    with Path(path).open("r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            row = json.loads(line)
            if db_id is None or row["db_id"] == db_id:
                rows.append(row)
    return rows

def search_value_index(span, value_index, db_id=None, top_k=20, min_score=70):
    span_norm = normalize(span)
    candidates = []

    for row in value_index:
        if db_id is not None and row["db_id"] != db_id:
            continue

        value_norm = row["normalized_value"]
        aliases = [normalize(a) for a in row.get("aliases", [])]

        exact = 100 if span_norm == value_norm else 0
        alias_score = 100 if span_norm in aliases else 0
        token_score = fuzz.token_sort_ratio(span_norm, value_norm)
        partial_score = fuzz.partial_ratio(span_norm, value_norm)

        score = max(exact, alias_score, token_score, partial_score)

        if score >= min_score:
            out = dict(row)
            out["match_score"] = score
            out["span"] = span
            candidates.append(out)

    candidates.sort(key=lambda x: (x["match_score"], x.get("frequency", 0)), reverse=True)
    return candidates[:top_k]

if __name__ == "__main__":
    idx = load_value_index(VALUE_INDEX_PATH)
    for span in ["Portland", "Billing disputes", "Home Fragrances", "NYC"]:
        print("\nSPAN:", span)
        for r in search_value_index(span, idx, top_k=5):
            print(r["db_id"], r["table"], r["column"], "=", r["value"], "score=", r["match_score"])
