# DuckDB Text-to-SQL Seed Bundle

This bundle was generated from the uploaded SQL seed files plus `bird_business_train_augmented_5000.jsonl`.

## Main outputs

- `sql/*_duckdb_seeded_corrected.sql`  
  One corrected/expanded DuckDB seed script per `db_id`.

- `value_index/value_index.jsonl`  
  Full value index for schema/value linking.

- `value_index/value_index.csv`  
  CSV version of the same index.

- `value_index/by_db/*_value_index.jsonl`  
  Per-database value indexes.

- `schema/schema_index.json`  
  Table/column schema metadata with filter-index flags.

- `schema/build_summary.csv`  
  Build summary per database.

- `value_index/lookup_value_index.py`  
  Fuzzy lookup example for NER `FILTER_VALUE` spans.

- `build_duckdb_databases.py`  
  Script to create `.duckdb` files from the generated SQL scripts.

## Design logic

For filter columns, the generated data includes realistic categorical coverage rather than only the exact values in one question.

Examples:

- `city` columns include many major U.S. cities, including `Portland`, `Austin`, `New York City`, `Chicago`, `Houston`, `Seattle`, etc.
- `state` columns include U.S. states and abbreviations.
- `region` columns include common business regions such as `East`, `West`, `Central`, `South`, `Northeast`, and `Pacific`.
- `product`, `category`, `issue`, `status`, `segment`, `ship mode`, and `food_type` columns include realistic domain values.
- Training SQL literals are injected back into the appropriate `db_id.table.column` where they can be mapped.

## Intended pipeline

```text
NER FILTER_VALUE span
→ search value_index
→ return candidate db_id.table.column.value
→ rerank if ambiguous
→ send linked schema to SQL generator
```

## Quick lookup example

```python
from value_index.lookup_value_index import load_value_index, search_value_index

idx = load_value_index("value_index/value_index.jsonl", db_id="retail_complains")
matches = search_value_index("Portland", idx, db_id="retail_complains")

for m in matches[:5]:
    print(m["db_id"], m["table"], m["column"], m["value"], m["match_score"])
```

## Build summary

Training records processed: 2840
Non-empty SQL literal values processed: 1240
SQL literal coverage in value index: 100.00%
Total value index rows: 10865

## Note

These are synthetic seed databases for Text-to-SQL development and schema/value linking tests, not real production data.

Date-like columns are kept as `TEXT` because many target SQLs use mixed date string patterns with `LIKE` and `SUBSTR`. Numeric measure columns such as `Sales`, `Price`, `Profit`, `Quantity`, `Amount`, and `Discount` are typed as numeric where possible.
